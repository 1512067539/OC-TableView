//
//  SceneDelegate.h
//  WMOCTableView
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

