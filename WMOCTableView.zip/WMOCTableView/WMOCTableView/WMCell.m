//
//  WMCell.m
//  WMOCTableView
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import "WMCell.h"

@interface WMCell()

@property (nonatomic, strong) UIView *backView;

@property (nonatomic, strong) UIImageView *iconImageView;

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UILabel *msgLabel;

@end


@implementation WMCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:self.backView];
        [self.backView addSubview:self.iconImageView];
        [self.backView addSubview:self.titleLabel];
        [self.backView addSubview:self.msgLabel];
    }
    return self;
}

#pragma mark - get
- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] init];
        _backView.frame = CGRectMake(10, 10, [UIScreen mainScreen].bounds.size.width - 20, 130);
        _backView.backgroundColor = [UIColor whiteColor];
        _backView.layer.masksToBounds = YES;
        _backView.layer.cornerRadius = 15;
    }
    return _backView;
}

- (UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.frame = CGRectMake(10, 10, 60, 60);
        _iconImageView.backgroundColor = [UIColor redColor];
    }
    return _iconImageView;
}

- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.frame = CGRectMake(CGRectGetMaxX(self.iconImageView.frame) + 10, 10, 250, 20);
        _titleLabel.text = @"阿斯顿发发电房打发的发送到发送到发送到发斯蒂芬啊阿斯顿发大法师打发";
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.font = [UIFont systemFontOfSize:17];
    }
    return _titleLabel;
}

- (UILabel *)msgLabel{
    if (!_msgLabel) {
        _msgLabel = [[UILabel alloc] init];
        _msgLabel.frame =  CGRectMake(CGRectGetMaxX(self.iconImageView.frame) + 10, CGRectGetMaxY(self.titleLabel.frame) + 10, 250, 40);
        _msgLabel.text = @"adfadfafafadfadfasdfasdfasdflasdfkasdfjalskdfjaslkdfjasdklfajsdflkasjdflaksdfjaskldfjalskdfjadslkfjasdklfajsdlfkasdjfs";
        _msgLabel.textColor = [UIColor blackColor];
        _msgLabel.numberOfLines = 2;
        _msgLabel.font = [UIFont systemFontOfSize:14];
    }
    return _msgLabel;
}

@end
